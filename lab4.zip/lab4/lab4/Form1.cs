﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace lab4
{
    public partial class Form1 : Form
    {
        private Panel panel;
        private Button upButton, downButton, leftButton, rightButton;
        private int circleSize = 50;
        private int circleX, circleY;

        public Form1()
        {
            InitializeComponent();
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Определяем размеры и положение формы
            this.ClientSize = new Size(400, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Создаем панель для отображения круга
            panel = new Panel();
            panel.Size = new Size(300, 300);
            panel.Location = new Point((this.ClientSize.Width - panel.Width) / 2, 50);
            panel.BorderStyle = BorderStyle.FixedSingle;
            panel.BackColor = Color.White;
            this.Controls.Add(panel);

            // Начальные координаты круга
            circleX = (panel.Width - circleSize) / 2;
            circleY = (panel.Height - circleSize) / 2;

            // Рисуем круг на панели
            DrawCircle();

            // Создаем кнопки для смещения круга
            upButton = CreateButton("Up", new Point((this.ClientSize.Width - 320) / 2, panel.Bottom + 10));
            downButton = CreateButton("Down", new Point((this.ClientSize.Width - 320) / 2 + 80, panel.Bottom + 10));
            leftButton = CreateButton("Left", new Point((this.ClientSize.Width - 320) / 2 + 160, panel.Bottom + 10));
            rightButton = CreateButton("Right", new Point((this.ClientSize.Width - 320) / 2 + 240, panel.Bottom + 10));

            // Привязываем обработчики событий к кнопкам
            upButton.Click += (sender, e) => MoveCircle(0, -20);
            downButton.Click += (sender, e) => MoveCircle(0, 20);
            leftButton.Click += (sender, e) => MoveCircle(-20, 0);
            rightButton.Click += (sender, e) => MoveCircle(20, 0);
        }

        private Button CreateButton(string text, Point location)
        {
            Button button = new Button();
            button.Text = text;
            button.Size = new Size(80, 30);
            button.Location = location;
            this.Controls.Add(button);
            return button;
        }

        private void DrawCircle()
        {
            Graphics g = panel.CreateGraphics();
            g.Clear(Color.White);
            g.FillEllipse(Brushes.Blue, circleX, circleY, circleSize, circleSize);
            g.Dispose();
        }

        private void MoveCircle(int deltaX, int deltaY)
        {
            // Проверяем, чтобы круг не выходил за границы панели
            if (circleX + deltaX >= 0 && circleX + deltaX <= panel.Width - circleSize &&
                circleY + deltaY >= 0 && circleY + deltaY <= panel.Height - circleSize)
            {
                circleX += deltaX;
                circleY += deltaY;
                DrawCircle();
            }
        }
    }
}
